import { Router } from "express";
import { db } from "./db";
import { 
  subscriptionPlans, 
  brandingConfig, 
  auditLogs, 
  paymentHistory,
  subscriptions,
  organizations,
  users,
  insertSubscriptionPlanSchema,
  insertBrandingConfigSchema
} from "@shared/schema";
import { eq, desc, sql, count, and, gte, lte } from "drizzle-orm";
import { requireOwner, logAudit } from "./rbac";

const router = Router();

// ========================
// SUBSCRIPTION PLANS MANAGEMENT (OWNER only)
// ========================

// Get all subscription plans
router.get("/plans", requireOwner, async (req, res) => {
  try {
    const plans = await db
      .select()
      .from(subscriptionPlans)
      .orderBy(subscriptionPlans.createdAt);

    res.json(plans);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get single plan
router.get("/plans/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const plan = await db.query.subscriptionPlans.findFirst({
      where: eq(subscriptionPlans.id, id),
    });

    if (!plan) {
      return res.status(404).json({ message: "Plano não encontrado" });
    }

    res.json(plan);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Create subscription plan
router.post("/plans", requireOwner, async (req, res) => {
  try {
    const planData = insertSubscriptionPlanSchema.parse(req.body);

    const [newPlan] = await db
      .insert(subscriptionPlans)
      .values(planData)
      .returning();

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "create_plan",
      entityType: "subscription_plan",
      entityId: newPlan.id,
      newValue: newPlan,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(201).json(newPlan);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Update subscription plan
router.put("/plans/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const existingPlan = await db.query.subscriptionPlans.findFirst({
      where: eq(subscriptionPlans.id, id),
    });

    if (!existingPlan) {
      return res.status(404).json({ message: "Plano não encontrado" });
    }

    const planData = insertSubscriptionPlanSchema.partial().parse(req.body);

    const [updatedPlan] = await db
      .update(subscriptionPlans)
      .set({ ...planData, updatedAt: new Date() })
      .where(eq(subscriptionPlans.id, id))
      .returning();

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "update_plan",
      entityType: "subscription_plan",
      entityId: id,
      oldValue: existingPlan,
      newValue: updatedPlan,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(updatedPlan);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Delete subscription plan
router.delete("/plans/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const existingPlan = await db.query.subscriptionPlans.findFirst({
      where: eq(subscriptionPlans.id, id),
    });

    if (!existingPlan) {
      return res.status(404).json({ message: "Plano não encontrado" });
    }

    await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id));

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "delete_plan",
      entityType: "subscription_plan",
      entityId: id,
      oldValue: existingPlan,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Plano deletado com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ========================
// BRANDING CONFIGURATION (OWNER only)
// ========================

// Get branding config
router.get("/branding", requireOwner, async (req, res) => {
  try {
    const configs = await db
      .select()
      .from(brandingConfig)
      .limit(1);

    const config = configs[0] || null;

    res.json(config);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Update branding config
router.put("/branding", requireOwner, async (req, res) => {
  try {
    const configData = insertBrandingConfigSchema.partial().parse(req.body);

    // Check if config exists
    const existingConfigs = await db
      .select()
      .from(brandingConfig)
      .limit(1);

    let updatedConfig;

    if (existingConfigs.length === 0) {
      // Create new config
      [updatedConfig] = await db
        .insert(brandingConfig)
        .values({ ...configData, updatedBy: req.user!.id })
        .returning();
    } else {
      // Update existing config
      [updatedConfig] = await db
        .update(brandingConfig)
        .set({ ...configData, updatedBy: req.user!.id, updatedAt: new Date() })
        .where(eq(brandingConfig.id, existingConfigs[0].id))
        .returning();
    }

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "update_branding",
      entityType: "branding_config",
      entityId: updatedConfig.id,
      oldValue: existingConfigs[0] || null,
      newValue: updatedConfig,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(updatedConfig);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// ========================
// AUDIT LOGS (OWNER only)
// ========================

// Get audit logs with filtering
router.get("/audit-logs", requireOwner, async (req, res) => {
  try {
    const { 
      page = "1", 
      limit = "50", 
      action, 
      userId,
      entityType,
      startDate,
      endDate 
    } = req.query;
    
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    let query = db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(limitNum)
      .offset(offset);

    // Apply filters
    const filters: any[] = [];

    // CRITICAL: OWNER can only see audit logs from their organization (tenant isolation)
    filters.push(eq(auditLogs.organizationId, req.user!.organizationId!));

    if (action && typeof action === "string") {
      filters.push(eq(auditLogs.action, action));
    }

    if (userId && typeof userId === "string") {
      filters.push(eq(auditLogs.userId, userId));
    }

    if (entityType && typeof entityType === "string") {
      filters.push(eq(auditLogs.entityType, entityType));
    }

    if (startDate && typeof startDate === "string") {
      filters.push(gte(auditLogs.createdAt, new Date(startDate)));
    }

    if (endDate && typeof endDate === "string") {
      filters.push(lte(auditLogs.createdAt, new Date(endDate)));
    }

    if (filters.length > 0) {
      query = query.where(and(...filters)) as any;
    }

    const logs = await query;

    // Get total count
    const totalResult = await db
      .select({ count: count() })
      .from(auditLogs)
      .where(filters.length > 0 ? and(...filters) : undefined);

    res.json({
      logs,
      total: totalResult[0]?.count || 0,
      page: pageNum,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get audit log details
router.get("/audit-logs/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const log = await db.query.auditLogs.findFirst({
      where: eq(auditLogs.id, id),
    });

    if (!log) {
      return res.status(404).json({ message: "Log não encontrado" });
    }

    // CRITICAL: OWNER can only view audit logs from their organization (tenant isolation)
    if (log.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    res.json(log);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ========================
// METRICS & ANALYTICS (OWNER only)
// ========================

// Get platform metrics
router.get("/metrics", requireOwner, async (req, res) => {
  try {
    const { period = "30" } = req.query;
    const days = parseInt(period as string);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // CRITICAL: OWNER can only see metrics from their organization (tenant isolation)
    const orgId = req.user!.organizationId!;
    
    const [
      totalUsers,
      myOrgSubscription,
      totalRevenue,
      newUsers,
      recentPayments
    ] = await Promise.all([
      db.select({ count: count() }).from(users).where(eq(users.organizationId, orgId)),
      db.select().from(subscriptions).where(eq(subscriptions.organizationId, orgId)).limit(1),
      db.select({ 
        total: sql<number>`COALESCE(SUM(${paymentHistory.amount}), 0)` 
      }).from(paymentHistory).where(
        and(
          eq(paymentHistory.organizationId, orgId),
          eq(paymentHistory.status, "succeeded")
        )
      ),
      db.select({ count: count() }).from(users).where(
        and(
          eq(users.organizationId, orgId),
          gte(users.createdAt, startDate)
        )
      ),
      db.select().from(paymentHistory)
        .where(eq(paymentHistory.organizationId, orgId))
        .orderBy(desc(paymentHistory.createdAt))
        .limit(10)
    ]);

    const subscription = myOrgSubscription[0];
    const mrr = subscription?.amount || 0;

    res.json({
      totalUsers: totalUsers[0]?.count || 0,
      subscriptionStatus: subscription?.status || "none",
      totalRevenue: totalRevenue[0]?.total || 0,
      newUsers: newUsers[0]?.count || 0,
      mrr: mrr,
      recentPayments,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get payment history
router.get("/payments", requireOwner, async (req, res) => {
  try {
    const { page = "1", limit = "50", status } = req.query;
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // CRITICAL: OWNER can only see payments from their organization (tenant isolation)
    const filters: any[] = [eq(paymentHistory.organizationId, req.user!.organizationId!)];

    if (status && typeof status === "string") {
      filters.push(eq(paymentHistory.status, status));
    }

    let query = db
      .select()
      .from(paymentHistory)
      .where(and(...filters))
      .orderBy(desc(paymentHistory.createdAt))
      .limit(limitNum)
      .offset(offset);

    const payments = await query;

    // Get total count
    const totalResult = await db
      .select({ count: count() })
      .from(paymentHistory)
      .where(and(...filters));

    res.json({
      payments,
      total: totalResult[0]?.count || 0,
      page: pageNum,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get subscription details for all organizations
router.get("/subscriptions", requireOwner, async (req, res) => {
  try {
    const { page = "1", limit = "50", status } = req.query;
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // CRITICAL: OWNER can only see subscriptions from their organization (tenant isolation)
    const filters: any[] = [eq(subscriptions.organizationId, req.user!.organizationId!)];

    if (status && typeof status === "string") {
      filters.push(eq(subscriptions.status, status as any));
    }

    let query = db
      .select()
      .from(subscriptions)
      .where(and(...filters))
      .orderBy(desc(subscriptions.createdAt))
      .limit(limitNum)
      .offset(offset);

    const subs = await query;

    // Get total count
    const totalResult = await db
      .select({ count: count() })
      .from(subscriptions)
      .where(and(...filters));

    res.json({
      subscriptions: subs,
      total: totalResult[0]?.count || 0,
      page: pageNum,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
