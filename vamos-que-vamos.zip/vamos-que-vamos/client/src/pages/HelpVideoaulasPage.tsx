import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, PlayCircle, Clock, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function HelpVideoaulasPage() {
  const [, setLocation] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" })
      .then(res => res.ok ? setIsAuthenticated(true) : setIsAuthenticated(false))
      .catch(() => setIsAuthenticated(false));
  }, []);

  const handleBack = () => {
    setLocation(isAuthenticated ? "/app/dashboard" : "/");
  };

  const videos = [
    {
      title: "Primeiros Passos no LUCREI",
      duration: "8 min",
      level: "Iniciante",
      description: "Aprenda a configurar sua conta e começar a usar a plataforma",
      views: "10.5k"
    },
    {
      title: "Como Criar e Gerenciar Clientes",
      duration: "12 min",
      level: "Iniciante",
      description: "Tutorial completo sobre gestão de clientes e suas informações",
      views: "8.2k"
    },
    {
      title: "Emissão de Faturas e Notas",
      duration: "15 min",
      level: "Intermediário",
      description: "Guia passo a passo para emitir faturas profissionais",
      views: "12.3k"
    },
    {
      title: "Controle de Fluxo de Caixa",
      duration: "18 min",
      level: "Intermediário",
      description: "Como acompanhar entradas e saídas em tempo real",
      views: "15.7k"
    },
    {
      title: "Conciliação Bancária Automática",
      duration: "20 min",
      level: "Avançado",
      description: "Automatize a reconciliação de extratos bancários",
      views: "6.8k"
    },
    {
      title: "Relatórios e Análises Avançadas",
      duration: "25 min",
      level: "Avançado",
      description: "Extraia insights poderosos dos seus dados financeiros",
      views: "9.1k"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-4 md:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={handleBack} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-2xl md:text-4xl sm:text-xl md:text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Videoaulas para Iniciantes
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Aprenda a usar o LUCREI com nossos tutoriais em vídeo
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">
          {videos.map((video, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
                <CardContent className="p-0">
                  <div className="relative aspect-video bg-gradient-to-br from-primary/20 to-primary/20 flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/80/30 transition-colors">
                    <PlayCircle className="h-16 w-16 text-white opacity-90 group-hover:scale-110 transition-transform" />
                    <div className="absolute top-2 right-2">
                      <Badge variant="secondary">{video.level}</Badge>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-white text-xs flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {video.duration}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-semibold text-lg mb-2">{video.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{video.description}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <TrendingUp className="h-3 w-3" />
                      <span>{video.views} visualizações</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16"
        >
          <Card className="bg-gradient-to-r from-primary/10 to-primary/10 border-primary/20">
            <CardContent className="p-4 md:p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Quer aprender mais?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Cadastre-se gratuitamente e tenha acesso a todos os nossos tutoriais e materiais de treinamento
              </p>
              <Button 
                size="lg"
                onClick={() => setLocation("/register")}
                className="bg-gradient-to-r from-primary to-primary/80"
              >
                Começar Agora
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
